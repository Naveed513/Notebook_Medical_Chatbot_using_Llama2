import os
import json
import time
import random
from langchain_google_genai import ChatGoogleGenerativeAI
from langgraph.graph import StateGraph

# 🔹 Set up API Key for Gemini 1.5 Flash
os.environ["GOOGLE_API_KEY"] = "AIzaSyCoZ5OCn4B6poJBo9_xv7MsRN5VsxVBEbo"
os.environ['GEMINI_API_KEY'] = "AIzaSyCoZ5OCn4B6poJBo9_xv7MsRN5VsxVBEbo"

# 🔹 Initialize Google Generative AI Chat Model
llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash")

# 🔹 Define Paths for Data Storage
NEWS_FILE = "news_headlines.txt"
EMAIL_FILE = "emails.txt"

# 🔹 Custom Memory Store (Dictionary-Based)
memory = {}

# 🔹 Utility Function: Handle Gemini Rate Limits
def invoke_with_retry(prompt, max_retries=5):
    """Invokes Gemini API with exponential backoff."""
    retries = 0
    while retries < max_retries:
        try:
            return llm.invoke(prompt).content.strip()
        except Exception as e:
            if "ResourceExhausted" in str(e):
                wait_time = (2 ** retries) + random.uniform(0, 1)
                print(f"Rate limit hit. Retrying in {wait_time:.2f} seconds...")
                time.sleep(wait_time)
                retries += 1
            else:
                return f"Error: {str(e)}"
    return "Error: Maximum retries exceeded."

def process_user_query(state):
    """Appends the user's query to the conversation history and returns state."""
    state["messages"].append({"role": "user", "content": state["user_query"]})
    return state

def interpret_intent(state):
    """Uses Gemini 1.5 Flash to determine user intent dynamically."""
    prompt = [
        {"role": "system", "content": "Classify the user query into one of the following categories: 'retrieve data', 'add data', 'analyze sentiment', or 'recall history'."},
        {"role": "user", "content": state["user_query"]}
    ]
    state["intent"] = invoke_with_retry(prompt)
    return state

def retrieve_data(state):
    """Retrieves news headlines or emails from the respective file."""
    file_path = NEWS_FILE if "news" in state["user_query"].lower() else EMAIL_FILE
    try:
        if os.path.exists(file_path):
            with open(file_path, "r") as file:
                state["tool_response"] = file.read()
        else:
            state["tool_response"] = "No data available."
    except Exception as e:
        state["tool_response"] = f"Error retrieving data: {str(e)}"
    return state

def add_data(state):
    """Adds a new news headline or email to the respective file."""
    file_path = NEWS_FILE if "news" in state["user_query"].lower() else EMAIL_FILE
    try:
        new_data = state["user_query"].replace("add news:", "").strip()
        with open(file_path, "a") as file:
            file.write(f"{new_data}\n")
        state["tool_response"] = "New headline added successfully!"
    except Exception as e:
        state["tool_response"] = f"Error adding data: {str(e)}"
    return state

def analyze_sentiment(state):
    """Uses Gemini 1.5 Flash to analyze sentiment and provide confidence scores."""
    prompt = [
        {"role": "system", "content": "Analyze the sentiment of the following news headline as 'positive' or 'negative' and provide a confidence score (0-100%)."},
        {"role": "user", "content": state["user_query"]}
    ]
    state["tool_response"] = invoke_with_retry(prompt)
    return state

def retrieve_from_memory(state):
    """Retrieves past conversation summaries from memory."""
    history = memory.get("chat_history")
    state["tool_response"] = history if history else "No conversation history available."
    return state

def summarize_interactions(state):
    """Summarizes the last 10 interactions using Gemini 1.5 Flash and updates memory."""
    messages = state["messages"][-10:]

    prompt = [
        {"role": "system", "content": "Summarize the following 10 user interactions concisely, preserving key details."},
        {"role": "user", "content": json.dumps(messages)}
    ]

    summary = invoke_with_retry(prompt)
    memory["chat_history"] = summary  # ✅ Correct memory update
    state["messages"] = []  # Reset interactions
    state["tool_response"] = "Conversations summarized to optimize memory."
    return state

def generate_response(state):
    """Uses Gemini 1.5 Flash to generate responses based on query, retrieved data, and memory."""
    prompt = [
        {"role": "system", "content": "You are a helpful AI assistant. Use the following context to generate a relevant response."},
        {"role": "user", "content": f"Query: {state['user_query']}\nContext: {state['tool_response']}"}
    ]

    state["tool_response"] = invoke_with_retry(prompt)
    state["messages"].append({"role": "assistant", "content": state["tool_response"]})
    memory["latest_interaction"] = {"user": state["user_query"], "bot": state["tool_response"]}  # ✅ Correct memory update
    return state

def end_node(state):
    """Explicit end state to prevent infinite recursion errors."""
    state["tool_response"] = "End of conversation."
    return state

# 🔹 Create Graph Using LangGraph
graph = StateGraph(state_schema=dict)

# Define Graph Nodes
graph.add_node("process_user_query", process_user_query)
graph.add_node("interpret_intent", interpret_intent)
graph.add_node("retrieve_data", retrieve_data)
graph.add_node("add_data", add_data)
graph.add_node("analyze_sentiment", analyze_sentiment)
graph.add_node("retrieve_from_memory", retrieve_from_memory)
graph.add_node("summarize_interactions", summarize_interactions)
graph.add_node("generate_response", generate_response)
graph.add_node("end", end_node)  # ✅ Explicit end state

# Define Workflow Logic
graph.set_entry_point("process_user_query")
graph.add_edge("process_user_query", "interpret_intent")
graph.add_conditional_edges("interpret_intent", lambda state: state["intent"], {
    "retrieve data": "retrieve_data",
    "add data": "add_data",
    "analyze sentiment": "analyze_sentiment",
    "recall history": "retrieve_from_memory"
})
graph.add_edge("retrieve_data", "generate_response")
graph.add_edge("add_data", "generate_response")
graph.add_edge("analyze_sentiment", "generate_response")
graph.add_edge("retrieve_from_memory", "generate_response")

# Fix Graph Recursion Issue by Adding an Explicit Stopping Condition
graph.add_conditional_edges("generate_response", lambda state: "summarize_interactions" if len(state["messages"]) >= 10 else "end", {
    "summarize_interactions": "summarize_interactions",
    "end": "end"  # ✅ Terminate execution
})
graph.add_edge("summarize_interactions", "generate_response")

# Compile the Agent
agent = graph.compile()

def run_agent(user_query):
    """Runs the AI agent with a given user query."""
    initial_state = {"messages": [], "user_query": user_query, "tool_response": ""}
    final_state = agent.invoke(initial_state)
    return final_state["messages"][-1]["content"]

# 🔹 Test Runs
print(run_agent("Show me today's news headlines."))
print(run_agent("Add news: AI is changing the future."))
print(run_agent("Analyze the sentiment of 'Stock market crashes'."))
print(run_agent("What did we discuss earlier?"))
